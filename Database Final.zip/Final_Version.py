import tkinter as tk
from tkinter import *
from tkinter import messagebox
from PIL import Image, ImageTk
from datetime import datetime
import pyodbc


conn = pyodbc.connect(
    "Driver={SQL Server Native Client 11.0};"
    "Server=ASUS-AZ;"
    "Database=OHMS;"
    "Trusted_Connection=yes;"
)


# ---------------------------------------------------------------------------------------------------------------------


def SignOut(wind):
    wind.withdraw()


# ---------------------------------------------------------------------------------------------------------------------

def add_appoin_console():
    wind = tk.Toplevel(window)
    wind.title("Schedule An Appointment")
    wind.geometry("1015x428")

    image = ImageTk.PhotoImage(file="hcs1.png")

    date = datetime.now()

    label1 = Label(wind, image=image)
    label1.pack()

    heading = Label(wind, text="Schedule An Appointment", font=("Calibri", 20, "bold"), fg="red")
    heading.pack()
    heading.place(x=380, y=10)

    label1 = tk.Label(wind, text="Appointment Date", font=("times new roman", 13, "bold"))
    label1.pack()
    label1.place(x=20, y=70)

    entry1 = tk.Entry(wind, width=30, fg="black", bg="white", textvariable=appoin)
    entry1.pack()
    entry1.place(x=200, y=70)

    # --------------------------------------------------------------------------------------------------------------------

    label2 = tk.Label(wind, text="Emergency Date", font=("times new roman", 13, "bold"))
    label2.pack()
    label2.place(x=20, y=120)

    entry2 = tk.Entry(wind, width=30, fg="black", bg="white", textvariable=eme)
    entry2.pack()
    entry2.place(x=200, y=120)

    # --------------------------------------------------------------------------------------------------------------------

    label3 = tk.Label(wind, text="Next Checkup", font=("times new roman", 13, "bold"))
    label3.pack()
    label3.place(x=20, y=170)

    entry3 = tk.Entry(wind, width=30, fg="black", bg="white", textvariable=next)
    entry3.pack()
    entry3.place(x=200, y=170)

    # --------------------------------------------------------------------------------------------------------------------

    label4 = tk.Label(wind, text="CNIC", font=("times new roman", 13, "bold"))
    label4.pack()
    label4.place(x=20, y=220)

    entry4 = tk.Entry(wind, width=30, fg="black", bg="white", textvariable=cnic)
    entry4.pack()
    entry4.place(x=200, y=220)

    # --------------------------------------------------------------------------------------------------------------------

    label5 = tk.Label(wind, text="Doctor", font=("times new roman", 13, "bold"))
    label5.pack()
    label5.place(x=20, y=270)

    entry5 = tk.Entry(wind, width=30, fg="black", bg="white", textvariable=doc_id)
    entry5.pack()
    entry5.place(x=200, y=270)

    # For the button Schedule Appointment

    plus_image = Image.open('plus.png')
    size_img = plus_image.resize((10, 10))
    plus_img = ImageTk.PhotoImage(size_img)

    schedule = tk.Button(wind, text=" Schedule Appointment", fg="black", font=("Calibri", 12), width=180, height=20,
                         image=plus_img, compound="left",command=lambda :create_appointments(conn,appoin.get(),eme.get(),next.get(),cnic.get(),doc_id.get()))
    schedule.pack()
    schedule.place(x=200, y=320)

    wind.mainloop()


def create_appointments(conn,appoin,eme,next,cnic,doc_id):
    print("Create")
    # appoin=input("Appointments: ")
    # emergency=input("Emergency Appointment: ")
    # next=input("Next checkup: ")
    # cnic=input("CNIC: ")
    # doctor= input("Doctor: ")

    cursor = conn.cursor()
    cursor.execute(
        "insert into Norm_Appointments (Appointments, Emergency_Appointment, Next_Checkup, CNIC, Doctor_Appointed) values(?,?,?,?,?);",
        (appoin,eme,next,cnic,doc_id))

    conn.commit()
    # check_patients(conn)


def delete_appoin_console():
    wind = tk.Toplevel(window)
    wind.title("Schedule An Appointment")
    wind.geometry("500x300")

    image = ImageTk.PhotoImage(file="hcs1.png")

    label1 = Label(wind, image=image)

    label1.pack()
    heading = Label(wind, text="Delete An Appointment", font=("Calibri", 20, "bold"), fg="red")
    heading.pack()

    heading.place(x=100, y=10)
    label1 = tk.Label(wind, text="SERIAL #", font=("times new roman", 13, "bold"))
    label1.pack()
    label1.place(x=20, y=70)

    entry1 = tk.Entry(wind, width=30, fg="black", bg="white", textvariable=serial)
    entry1.pack()
    entry1.place(x=200, y=70)

    plus_image = Image.open('plus.png')
    size_img = plus_image.resize((10, 10))
    plus_img = ImageTk.PhotoImage(size_img)

    delete = tk.Button(wind,text=" Delete Appointments", fg="black", font=("Calibri", 12), width=220, height=30,
                     image=plus_img, compound="left",command=lambda :delete_appointments(conn,serial.get()))
    delete.pack()
    delete.place(x=90, y=150)

    wind.mainloop()


def delete_appointments(conn,serial):
    print("Delete")
    # entry=input("Enter the Appointment Date you want to remove: ")
    cursor = conn.cursor()
    cursor.execute("Delete from Norm_Appointments where serial_number = ?", (serial))

    conn.commit()
    # check_patients(conn)


def update_appoin_console():
    wind = tk.Toplevel(window)
    wind.title("PATIENT")
    wind.geometry("600x600")

    options = [
        "Appointment",
        "Emergency_Appointment",
        "Next_Checkup",
        "CNIC",
        "Doctor_Appointed"
    ]

    clicked = StringVar()

    # initial menu text
    clicked.set("Select To Update")

    label12 = tk.Label(wind, text="SERIAL #  ", font=("times new roman", 13, "bold"))
    label12.pack()
    label12.place(x=50, y=50)

    entry12 = tk.Entry(wind, width=30, fg="black", bg="white", textvariable=serial)
    entry12.pack()
    entry12.place(x=150, y=50)

    label2 = tk.Label(wind, text="What to Update: ", font=("times new roman", 13, "bold"))
    label2.pack()
    label2.place(x=50, y=150)

    drop = OptionMenu(wind, clicked, *options)
    drop.place(x=200, y=150)

    label12 = tk.Label(wind, text="Updated Value: ", font=("times new roman", 13, "bold"))
    label12.pack()
    label12.place(x=50, y=190)

    entry12 = tk.Entry(wind, width=30, fg="black", bg="white", textvariable=updatevalue)
    entry12.pack()
    entry12.place(x=200, y=190)

    # Create Dropdown menu

    button1 = tk.Button(wind, text="UPDATE", fg="#181D31", relief="ridge", bg="#EDEDED",
                        font=("times new roman", 16, "bold"), width=10, height=1,

                        command=lambda: update_appointments(conn, clicked.get(), updatevalue.get(),serial.get()))
    button1.pack()
    button1.place(x=150, y=250)

    wind.mainloop()


def update_appointments(conn,val,update,serial):

    if val == "Appointments":
        cursor = conn.cursor()
        cursor.execute("Update Norm_Appointments set Appointments = ? where serial_number = ?", (update, serial))
    elif val == "Emergency_Appointment":
        cursor = conn.cursor()
        cursor.execute("Update Norm_Appointments set Emergency_Appointment = ? where serial_number = ?", (update, serial))
    elif val == "Next_Checkup":
        cursor = conn.cursor()
        cursor.execute("Update Norm_Appointments set Next_Checkup = ? where serial_number = ?", (update, serial))
    elif val == "CNIC":
        cursor = conn.cursor()
        cursor.execute("Update Norm_Appointments set CNIC = ? where serial_number = ?", (update, serial))
    elif val == "Doctor_Appointed":
        cursor = conn.cursor()
        cursor.execute("Update Norm_Appointments set Doctor_Appointed = ? where serial_number = ?", (update, serial))

    conn.commit()


def appointments(doc):
    appoin = tk.Toplevel(window)
    appoin.title("APPOINTMENTS")
    appoin.geometry("800x300")
    appoin.configure(bg="#D6E4E5")

    image = Image.open(
        'pngtree-medical-doctor-science-background-backgroundbackgrounddoctorsmedicalmedicinehealth-image_68227.png')
    tk_image = ImageTk.PhotoImage(image)

    label = tk.Label(appoin, image=tk_image, compound='center', font=("times new roman", 13, "bold"),
                     background="#B5D5C5")
    label.pack()
    label.place()
    doc.withdraw()
    appoin_label = tk.Label(appoin, text="APPOINTMENTS", bg="#BAD1C2", fg="#181D31",
                            font=("times new roman", 18, "bold"))
    appoin_label.pack()
    appoin_label.place(x=270, y=5)

    dashboard = tk.Button(appoin, text=" ADD APPOINTMENT ", fg="black", bg="#98B4A6", font=("Calibri", 15, "bold"),
                          width=20,
                          height=1,
                          compound="left",command=lambda :add_appoin_console())

    dashboard.pack()
    dashboard.place(x=250, y=100)

    dashboard = tk.Button(appoin, text=" DELETE APPOINTMENT ", fg="black", bg="#98B4A6", font=("Calibri", 15, "bold"),
                          width=20, height=1,
                          compound="left",command=lambda : delete_appoin_console())

    dashboard.pack()
    dashboard.place(x=500, y=100)

    dashboard = tk.Button(appoin, text=" UPDATE INFO ", fg="black", bg="#98B4A6", font=("Calibri", 15, "bold"),
                          width=20,
                          height=1,
                          compound="left",command=lambda :update_appoin_console())

    dashboard.pack()
    dashboard.place(x=400, y=200)

    appoin.mainloop()


# ---------------------------------------------------------------------------------------------------------------------


####### PATIENTS ###########

def medical_console():
    wind = tk.Toplevel(window)
    wind.title("MEDICAL RECORD")
    wind.geometry("600x600")

    label1 = tk.Label(wind, text="CNIC", font=("times new roman", 13, "bold"))
    label1.pack()
    label1.place(x=20, y=50)

    entry2 = tk.Entry(wind, width=30, fg="black", bg="white", textvariable=cnic)
    entry2.pack()
    entry2.place(x=160, y=50)

    button1 = tk.Button(wind, text="ENTER", fg="#181D31", relief="ridge", bg="#EDEDED",
                        font=("times new roman", 16, "bold"), width=10, height=1,
                        command=lambda: display_medical_records(conn,cnic.get()))
    button1.pack()
    button1.place(x=150, y=200)

    wind.mainloop()


def display_medical_records(conn,cnic):
    print("Read")
    # entry=input("Enter Patient's CNIC : ")
    temp=False
    cursor = conn.cursor()
    cursor.execute("select * from MedicalRecord where CNIC=?",(cnic))
    i=0
    for row in cursor:
        # if entry == row[5]:
        #     print(row)
        #     temp=True
        my_w = tk.Tk()
        my_w.geometry("1100x250")
        for j in range(len(row)):
            e = Entry(my_w, width=30, fg='blue')
            e.grid(row=i, column=j)
            e.insert(END, row[j])
        i = i + 1
        my_w.mainloop()

    if temp==False:
        print("Invalid cnic")


def display_console():
    wind = tk.Toplevel(window)
    wind.title("PATIENT")
    wind.geometry("600x600")

    label1 = tk.Label(wind, text="CNIC", font=("times new roman", 13, "bold"))
    label1.pack()
    label1.place(x=20, y=50)

    entry2 = tk.Entry(wind, width=30, fg="black", bg="white", textvariable=cnic)
    entry2.pack()
    entry2.place(x=160, y=50)

    button1 = tk.Button(wind, text="ENTER", fg="#181D31", relief="ridge", bg="#EDEDED",
                        font=("times new roman", 16, "bold"), width=10, height=1,command=lambda : Display_patient_data(conn,cnic.get()))
    button1.pack()
    button1.place(x=150, y=200)

    wind.mainloop()


def Display_patient_data(conn,cnic):
    print("Read")
    temp=False


    cursor = conn.cursor()
    cursor.execute("Select * from Clients where CNIC=? ",(cnic))
    i=0
    for row in cursor:
        # if row[2]==cnic:
        #     temp = True
            my_w = tk.Tk()
            my_w.geometry("1000x250")

            for j in range(len(row)):
                e = Entry(my_w, width=30, fg='blue')
                e.grid(row=i, column=j)
                e.insert(END, row[j])
            i = i + 1
            my_w.mainloop()



    if temp == False:
        print("This patient doesn't exist in our database")

    print()



def add_patient_console():

    wind = tk.Toplevel(window)
    wind.title("SIGN IN")
    wind.geometry("1000x700")

    # image = Image.open('360_F_216472247_cT66WDoS0fp1s3wC7eaykMJNDGVbOBPq.jpg')
    # tk_image = ImageTk.PhotoImage(image)
    #
    # label = tk.Label(wind, image=tk_image, compound='center', font=("times new roman", 13, "bold"))
    # label.pack()
    # label.place()

    label1 = tk.Label(wind, text="FIRST NAME", font=("times new roman", 13, "bold"))
    label1.pack()
    label1.place(x=20, y=50)

    entry2 = tk.Entry(wind, width=30, fg="black", bg="white",textvariable=f_name)
    entry2.pack()
    entry2.place(x=160, y=50)

    label1 = tk.Label(wind, text="LAST NAME", font=("times new roman", 13, "bold"))
    label1.pack()
    label1.place(x=20, y=150)

    entry2 = tk.Entry(wind, width=30, fg="black", bg="white",textvariable=l_name)
    entry2.pack()
    entry2.place(x=160, y=150)

    label1 = tk.Label(wind, text="CNIC", font=("times new roman", 13, "bold"))
    label1.pack()
    label1.place(x=20, y=250)

    entry2 = tk.Entry(wind, width=30, fg="black", bg="white",textvariable=cnic)
    entry2.pack()
    entry2.place(x=160, y=250)

    label1 = tk.Label(wind, text="MOB NUMBER", font=("times new roman", 13, "bold"))
    label1.pack()
    label1.place(x=20, y=350)

    entry2 = tk.Entry(wind, width=30, fg="black", bg="white",textvariable=mob)
    entry2.pack()
    entry2.place(x=160, y=350)


    label1 = tk.Label(wind, text="MOB NUMBER\n(Emergency)", font=("times new roman", 13, "bold"))
    label1.pack()
    label1.place(x=20, y=450)

    entry2 = tk.Entry(wind, width=30, fg="black", bg="white",textvariable=em_mob)
    entry2.pack()
    entry2.place(x=160, y=450)

    label1 = tk.Label(wind, text="EMAIL", font=("times new roman", 13, "bold"))
    label1.pack()
    label1.place(x=20, y=550)

    entry2 = tk.Entry(wind, width=30, fg="black", bg="white",textvariable=email)
    entry2.pack()
    entry2.place(x=160, y=550)

    button1 = tk.Button(wind, text="ENTER", fg="#181D31", relief="ridge", bg="#EDEDED",
                        font=("times new roman", 16, "bold"), width=10, height=1,command=lambda : add_patient(conn,f_name.get(),l_name.get(),cnic.get(),mob.get(),em_mob.get(),email.get()))
    button1.pack()
    button1.place(x=150, y=600)

    wind.mainloop()


def add_patient(conn,fname,lname,cnic,mob,eme,email):
    print("Create")

    cursor = conn.cursor()
    cursor.execute(
        "insert into Clients (First_Name, Last_Name, CNIC, Primary_Contact_Number, Emergency_Contact_Number, Email_Address) values(?,?,?,?,?,?);",
        (fname,lname,cnic,mob,eme,email))

    conn.commit()
    print("------------------------------")


def update_patient_console():
    wind = tk.Toplevel(window)
    wind.title("PATIENT")
    wind.geometry("600x600")

    # label1 = tk.Label(wind, text="CNIC", font=("times new roman", 13, "bold"))
    # label1.pack()
    # label1.place(x=20, y=50)
    #
    # entry2 = tk.Entry(wind, width=30, fg="black", bg="white", textvariable=cnic)
    # entry2.pack()
    # entry2.place(x=160, y=50)
    #
    # label1 = tk.Label(wind, text="VALUE", font=("times new roman", 13, "bold"))
    # label1.pack()
    # label1.place(x=20, y=150)
    #
    # entry2 = tk.Entry(wind, width=30, fg="black", bg="white", textvariable=value)
    # entry2.pack()
    # entry2.place(x=160, y=150)

    options = [
        "First_Name",
        "Last_Name",
        "CNIC",
        "Primary_Contact_Number",
        "Emergency_Contact_Number",
        "Email_Address"
    ]

    clicked = StringVar()

    # initial menu text
    clicked.set("Select To Update")

    label2 = tk.Label(wind, text="What to Update: ", font=("times new roman", 13, "bold"))
    label2.pack()
    label2.place(x=50, y=150)

    drop = OptionMenu(wind, clicked, *options)
    drop.place(x=200, y=150)

    # Create button, it will change label text
    button = Button(wind, text="click Me")

    label12 = tk.Label(wind, text="Updated Value: ", font=("times new roman", 13, "bold"))
    label12.pack()
    label12.place(x=50, y=190)

    entry12 = tk.Entry(wind, width=30, fg="black", bg="white", textvariable=updatevalue)
    entry12.pack()
    entry12.place(x=200, y=190)

    # Create Dropdown menu



    button1 = tk.Button(wind, text="UPDATE", fg="#181D31", relief="ridge", bg="#EDEDED",
                        font=("times new roman", 16, "bold"), width=10, height=1,

                        command=lambda:update_patient_record(conn, clicked.get(), cnic.get()))
    button1.pack()
    button1.place(x=150, y=250)

    wind.mainloop()


def delete_patient_console():
    wind = tk.Toplevel(window)
    wind.title("PATIENT")
    wind.geometry("600x600")



    label1 = tk.Label(wind, text="CNIC", font=("times new roman", 13, "bold"))
    label1.pack()
    label1.place(x=20, y=100)

    entry2 = tk.Entry(wind, width=30, fg="black", bg="white",textvariable=cnic)
    entry2.pack()
    entry2.place(x=160, y=100)

    button1 = tk.Button(wind, text="ENTER", fg="#181D31", relief="ridge", bg="#EDEDED",
                        font=("times new roman", 16, "bold"), width=10, height=1,command=lambda : delete_patient(conn,cnic.get()))
    button1.pack()
    button1.place(x=150, y=200)

    wind.mainloop()


def delete_patient(conn,cnic):
    print("Delete")
    # entry=input("Enter Patient's CNIC: ")
    cursor = conn.cursor()
    cursor.execute("Delete from Clients where CNIC = ?", (cnic))
    conn.commit()
    # Display_patient_data(conn)


def patients(doc):
    pat = tk.Toplevel(window)
    pat.title("APPOINTMENTS")
    pat.geometry("1000x400")
    pat.configure(bg="#D6E4E5", borderwidth='20', relief="ridge")

    image = Image.open('depositphotos_21337147-stock-photo-empty-background-of-modern-factory.jpg')
    tk_image = ImageTk.PhotoImage(image)

    label = tk.Label(pat, image=tk_image, compound='center', font=("times new roman", 13, "bold"),
                     background="#B5D5C5")
    label.pack()
    label.place()

    doc.withdraw()

    pat_label = tk.Label(pat, text="PATIENTS", bg="#BAD1C2", fg="#181D31",
                         font=("times new roman", 18, "bold"))
    pat_label.pack()
    pat_label.place(x=350, y=10)

    dashboard = tk.Button(pat, text=" ADD PATIENT ", fg="black", bg="#98B4A6", font=("Calibri", 15, "bold"), width=20,
                          height=1,
                          compound="left",command=lambda :add_patient_console())

    dashboard.pack()
    dashboard.place(x=40, y=100)

    dashboard = tk.Button(pat, text=" DELETE PATIENTS ", fg="black", bg="#98B4A6", font=("Calibri", 15, "bold"),
                          width=20, height=1,
                          compound="left",command=lambda :delete_patient_console())

    dashboard.pack()
    dashboard.place(x=300, y=100)

    dashboard = tk.Button(pat, text=" MEDICAL RECORD ", fg="black", bg="#98B4A6", font=("Calibri", 15, "bold"),
                          width=20,
                          height=1,
                          compound="left",command=lambda :medical_console())

    dashboard.pack()
    dashboard.place(x=300, y=200)

    dashboard = tk.Button(pat, text=" DISPLAY INFO ", fg="black", bg="#98B4A6", font=("Calibri", 15, "bold"),
                          width=20,
                          height=1,
                          compound="left",command=lambda :display_console())

    dashboard.pack()
    # dashboard.place(x=560, y=200)
    dashboard.place(x=560, y=100)


# ---------------------------------------------------------------------------------------------------------------------


def bloodbank(conn):
    print("Read")
    temp = False

    cursor = conn.cursor()
    cursor.execute("Select * from BloodBank")
    i = 0
    my_w = tk.Tk()
    my_w.geometry("700x250")
    for row in cursor:
        for j in range(len(row)):
            e = Entry(my_w, width=30, fg='blue')
            e.grid(row=i, column=j)
            e.insert(END, row[j])
        i = i + 1
    my_w.mainloop()


def edit_profile_console():
    wind = tk.Toplevel(window)
    wind.title("PATIENT")
    wind.geometry("600x600")

    label12 = tk.Label(wind, text="DOCTOR ID ", font=("times new roman", 13, "bold"))
    label12.pack()
    label12.place(x=50, y=50)

    entry12 = tk.Entry(wind, width=30, fg="black", bg="white", textvariable=doc_id)
    entry12.pack()
    entry12.place(x=150, y=50)

    options = [
        "First_Name",
        "Last_Name",
        "Qualification",
        "Specialization",
        "Contact_detail",
        "Client"
    ]

    clicked = StringVar()

    # initial menu text
    clicked.set("Select To Update")

    label2 = tk.Label(wind, text="What to Update: ", font=("times new roman", 13, "bold"))
    label2.pack()
    label2.place(x=50, y=150)

    drop = OptionMenu(wind, clicked, *options)
    drop.place(x=200, y=150)

    label12 = tk.Label(wind, text="Updated Value: ", font=("times new roman", 13, "bold"))
    label12.pack()
    label12.place(x=50, y=190)

    entry12 = tk.Entry(wind, width=30, fg="black", bg="white", textvariable=updatevalue)
    entry12.pack()
    entry12.place(x=200, y=190)

    # Create Dropdown menu

    button1 = tk.Button(wind, text="UPDATE", fg="#181D31", relief="ridge", bg="#EDEDED",
                        font=("times new roman", 16, "bold"), width=10, height=1,

                        command=lambda: edit_profile(conn, clicked.get(), updatevalue.get(), doc_id.get()))
    button1.pack()
    button1.place(x=150, y=250)

    wind.mainloop()


def edit_profile(conn,val,update,id):
    print("Update")
    # ID = input("Enter Your Doctor ID ")
    # print("Note: please make sure to write exact words given below!")
    # val = input("Type >> first name, last name, qualifications, specialization, contact detail, client: ")

    if val == "First_Name":

        cursor = conn.cursor()
        cursor.execute("Update Doctors set First_Name = ? where Doctor_ID = ?", (update, id))
    elif val == "Last_Name":

        cursor = conn.cursor()
        cursor.execute("Update Doctors set Last_Name = ? where Doctor_ID = ?", (update, id))
    elif val == "Qualifications":

        cursor = conn.cursor()
        cursor.execute("Update Doctors set Qualifications = ? where Doctor_ID = ?", (update, id))
    elif val == "Specialization":

        cursor = conn.cursor()
        cursor.execute("Update Doctors set Specialization = ? where Doctor_ID = ?", (update, id))
    elif val == "Contact_Detail":

        cursor = conn.cursor()
        cursor.execute("Update Doctors set Contact_Detail = ? where Doctor_ID = ?", (update, id))

    elif val == "Client":

        cursor = conn.cursor()
        cursor.execute("Update Doctors set Client = ? where Doctor_ID = ?", (update, id))

    # cursor.execute("Update Appointments set val= ? where CNIC = ?", (data, cnic))

    conn.commit()


def read(conn,username,userid):
    flag = True
    print("Read")
    cursor = conn.cursor()
    cursor.execute("Select * from Doctors")
    li = username.split()

    # for row in cursor:
    #     if row[0] == li[0]:
    #         print(row[0])
    #         break
    #
    # if flag == False:
    #     print("Sorry")

    for row in cursor:

            if row[2]==int(userid):
                return flag
    if flag == False:
        print("Invalid")


def doctor_console(wind,username,user_id):

    #LOG IN
    fun=read(conn,username,user_id)
    if fun == True:

        doc = tk.Toplevel(window)
        doc.title("DOCTOR PORTAL")
        doc.geometry("800x600")
        wind.withdraw()

        image = Image.open('depositphotos_21337147-stock-photo-empty-background-of-modern-factory.jpg')
        tk_image = ImageTk.PhotoImage(image)

        label = tk.Label(doc, image=tk_image, compound='center', font=("times new roman", 13, "bold"), relief="ridge",
                         borderwidth="10", background="#B5D5C5")
        label.pack()
        label.place()



        date = datetime.now()

        label1 = tk.Label(doc, text=f"{date:%A, %B %d, %Y}", font=("times new roman", 13, "bold"), background="#B5D5C5",
                          fg="#181D31")
        label1.pack()
        label1.place(x=600, y=10)

        home = Image.open("depositphotos_213277630-stock-photo-hospital-icon-monochrome-style-design.jpg")
        size_home = home.resize((100, 100))
        new_home = ImageTk.PhotoImage(size_home)

        dashboard = tk.Button(doc, text=" Dashboard ", fg="black", bg="#98B4A6", font=("Calibri", 15, "bold"), width="200",
                              height=150, image=new_home,
                              compound="left")

        dashboard.pack()
        dashboard.place(x=40, y=100)

        home1 = Image.open("360_F_243681031_AFhiw4v0jxkGxsRwTBH6245DYdBvfwyg.jpg")
        size_home1 = home1.resize((100, 100))
        new_home1 = ImageTk.PhotoImage(size_home1)

        dashboard = tk.Button(doc, text="  PATIENTS ", fg="black", bg="#98B4A6", font=("Calibri", 15, "bold"), width="200",
                              height=150, image=new_home1,
                              compound="left", command=lambda: patients(doc))

        dashboard.pack()
        dashboard.place(x=300, y=100)

        home2 = Image.open("360_F_216472247_cT66WDoS0fp1s3wC7eaykMJNDGVbOBPq.jpg")
        size_home2 = home2.resize((80, 80))
        new_home2 = ImageTk.PhotoImage(size_home2)

        dashboard = tk.Button(doc, text=" APPOINTMENTS ", fg="black", bg="#98B4A6", font=("Calibri", 15, "bold"),
                              width="240",
                              height=150, image=new_home2,
                              compound="left", command=lambda: appointments(doc))

        dashboard.pack()
        dashboard.place(x=540, y=100)

        home3 = Image.open("blood-donation-icon-vector-17947521.jpg")
        size_home3 = home3.resize((100, 100))
        new_home3 = ImageTk.PhotoImage(size_home3)

        dashboard = tk.Button(doc, text=" BLOOD-BANK ", fg="black", bg="#98B4A6", font=("Calibri", 15, "bold"),
                              width="280",
                              height=130, image=new_home3,
                              compound="left",command=lambda : bloodbank(conn))

        dashboard.pack()
        dashboard.place(x=40, y=300)

        home4 = Image.open("11.webp")
        size_home4 = home4.resize((100, 100))
        new_home4 = ImageTk.PhotoImage(size_home4)

        dashboard = tk.Button(doc, text=" EDIT-PROFILE ", fg="black", bg="#98B4A6", font=("Calibri", 15, "bold"),
                              width="280",
                              height=130, image=new_home4,
                              compound="left",command=lambda : edit_profile_console())

        dashboard.pack()
        dashboard.place(x=400, y=300)

        button1 = tk.Button(doc, text="SIGN-OUT", fg="#181D31", relief="ridge", bg="#E0ECE4",
                            font=("times new roman", 14, "bold"), width=10, height=1, command=lambda : SignOut(doc))
        button1.pack()
        button1.place(x=660, y=550)

        doc.mainloop()

    # else:
    #     print("Invalid")


def signing_in_Doctor():
    wind = tk.Toplevel(window)
    wind.title("SIGN IN")
    wind.geometry("600x400")

    image = Image.open('360_F_216472247_cT66WDoS0fp1s3wC7eaykMJNDGVbOBPq.jpg')
    tk_image = ImageTk.PhotoImage(image)

    label = tk.Label(wind, image=tk_image, compound='center', font=("times new roman", 13, "bold"))
    label.pack()
    label.place()

    label1 = tk.Label(wind, text="USERNAME", font=("times new roman", 13, "bold"))
    label1.pack()
    label1.place(x=20, y=100)

    entry2 = tk.Entry(wind, width=30, fg="black", bg="white", textvariable=user_name)
    entry2.pack()
    entry2.place(x=130, y=100)

    label1 = tk.Label(wind, text="PASSWORD", font=("times new roman", 13, "bold"))
    label1.pack()
    label1.place(x=20, y=160)

    entry2 = tk.Entry(wind, width=30, fg="black", bg="white", textvariable=user_pass)
    entry2.pack()
    entry2.place(x=130, y=160)
    button1 = tk.Button(wind, text="LOG IN", fg="#181D31", relief="ridge", bg="#EDEDED",
                        font=("times new roman", 16, "bold"), width=10, height=1, command=lambda: doctor_console(wind,user_name.get(),user_pass.get()))
    button1.pack()
    button1.place(x=150, y=250)

    wind.mainloop()


def sign_in_client(windo, cnic, passw):
    # cnic = input("Enter your CNIC: ")
    # password = input("Enter your password: ")

    c = conn.cursor()
    c.execute("select * from credential_client")

    temp = False
    for i in c:
        if i[0] == cnic and i[1] == passw:
            temp = True
    if temp:
        print("Login Successful")
        ClientPortal(windo)
    else:
        print("Login Unsuccessful")


def signing_in_Client():
    wind = tk.Toplevel(window)
    wind.title("SIGN IN")
    wind.geometry("600x400")

    image = Image.open('360_F_216472247_cT66WDoS0fp1s3wC7eaykMJNDGVbOBPq.jpg')
    tk_image = ImageTk.PhotoImage(image)

    label = tk.Label(wind, image=tk_image, compound='center', font=("times new roman", 13, "bold"))
    label.pack()
    label.place()

    label1 = tk.Label(wind, text="USERNAME", font=("times new roman", 13, "bold"))
    label1.pack()
    label1.place(x=20, y=100)

    entry2 = tk.Entry(wind, width=30, fg="black", bg="white", textvariable=cnic)
    entry2.pack()
    entry2.place(x=130, y=100)

    label1 = tk.Label(wind, text="PASSWORD", font=("times new roman", 13, "bold"))
    label1.pack()
    label1.place(x=20, y=160)

    entry2 = tk.Entry(wind, width=30, fg="black", bg="white", textvariable=user_pass)
    entry2.pack()
    entry2.place(x=130, y=160)
    button1 = tk.Button(wind, text="LOG IN", fg="#181D31", relief="ridge", bg="#EDEDED",
                        font=("times new roman", 16, "bold"), width=10, height=1,command=lambda :sign_in_client(wind, cnic.get(),user_pass.get()))
    button1.pack()
    button1.place(x=150, y=250)

    wind.mainloop()


# ---------------------------------------------------------------------------------------------------------------------

def ViewPrescriptionGUI():
    wind = tk.Toplevel(window)
    wind.title("View An Prescriptions")
    wind.geometry("500x300")

    label1 = Label(wind, image=image)
    label1.pack()

    heading = Label(wind, text="View Prescriptions", font=("Calibri", 20, "bold"), fg="red")
    heading.pack()
    heading.place(x=100, y=10)

    wind.mainloop()


def BloodBankGUI():
    wind = tk.Toplevel(window)
    wind.title("Blood Bank")
    wind.geometry("310x250")

    image = ImageTk.PhotoImage(file="hcs1.png")

    label1 = Label(wind, image=image)
    label1.pack()

    c = conn.cursor()
    c.execute("Select * from BloodBank")
    i = 0
    for temp in c:
        for j in range(len(temp)):
            e = Entry(label1, width=10, fg='blue')
            e.grid(row=i, column=j)
            e.insert(END, temp[j])
        i = i + 1

    wind.mainloop()


def UpdatePatientGUI():
    wind = tk.Toplevel(window)
    wind.title("PATIENT")
    wind.geometry("600x600")

    options = [
        "First_Name",
        "Last_Name",
        "CNIC",
        "Primary_Contact_Number",
        "Emergency_Contact_Number",
        "Email_Address"
    ]

    clicked = StringVar()

    # initial menu text
    clicked.set("Select To Update")

    label2 = tk.Label(wind, text="What to Update: ", font=("times new roman", 13, "bold"))
    label2.pack()
    label2.place(x=50, y=150)

    drop = OptionMenu(wind, clicked, *options)
    drop.place(x=200, y=150)

    label12 = tk.Label(wind, text="Updated Value: ", font=("times new roman", 13, "bold"))
    label12.pack()
    label12.place(x=50, y=190)

    entry12 = tk.Entry(wind, width=30, fg="black", bg="white", textvariable=updatevalue)
    entry12.pack()
    entry12.place(x=200, y=190)

    # Create Dropdown menu

    button1 = tk.Button(wind, text="UPDATE", fg="#181D31", relief="ridge", bg="#EDEDED",
                        font=("times new roman", 16, "bold"), width=10, height=1,

                        command=lambda: update_patient_record(conn, clicked.get(), updatevalue.get(), cnic.get()))
    button1.pack()
    button1.place(x=150, y=250)

    wind.mainloop()


def ManageAppointmentsGUI():
    wind = tk.Toplevel()
    wind.title("Manage Appointments")
    wind.geometry("1015x428")

    image = ImageTk.PhotoImage(file="hcs1.png")

    date = datetime.now()

    label1 = Label(wind, image=image)
    label1.pack()

    heading = Label(wind, text="Manage Appointments", font=("Calibri", 20, "bold"), fg="red")
    heading.pack()
    heading.place(x=380, y=10)

    plus_image = Image.open('plus.png')
    size_img = plus_image.resize((20, 20))
    plus_img = ImageTk.PhotoImage(size_img)

    label1 = tk.Label(wind, text="CNIC #", font=("times new roman", 13, "bold"))
    label1.pack()
    label1.place(x=120, y=70)

    entry1 = tk.Entry(wind, width=30, fg="black", bg="white", textvariable=cnic)
    entry1.pack()
    entry1.place(x=200, y=74)

    view = tk.Button(wind, text=" View Appointments", fg="black", font=("Calibri", 18), width=260, height=40,
                     image=plus_img, compound="left", command=lambda: View_appointments(conn, cnic.get()))

    view.pack()
    view.place(x=200, y=200)

    delete = tk.Button(wind, text=" Delete Appointments", fg="black", font=("Calibri", 18), width=260, height=40,
                       image=plus_img, compound="left", command=lambda: delete_appointmentsGUI())

    delete.pack()
    delete.place(x=550, y=200)

    wind.mainloop()


def ScheduleAnAppointmentGUI():
    wind = tk.Toplevel(window)
    wind.title("Schedule An Appointment")
    wind.geometry("1015x428")

    image = ImageTk.PhotoImage(file="hcs1.png")

    date = datetime.now()

    label1 = Label(wind, image=image)
    label1.pack()

    heading = Label(wind, text="Schedule An Appointment", font=("Calibri", 20, "bold"), fg="red")
    heading.pack()
    heading.place(x=380, y=10)

    label1 = tk.Label(wind, text="Appointment Date", font=("times new roman", 13, "bold"))
    label1.pack()
    label1.place(x=20, y=70)

    entry1 = tk.Entry(wind, width=30, fg="black", bg="white", textvariable=appoin_date)
    entry1.pack()
    entry1.place(x=200, y=70)

    # --------------------------------------------------------------------------------------------------------------------

    label2 = tk.Label(wind, text="Emergency Date", font=("times new roman", 13, "bold"))
    label2.pack()
    label2.place(x=20, y=120)

    entry2 = tk.Entry(wind, width=30, fg="black", bg="white", textvariable=eme_appoin)
    entry2.pack()
    entry2.place(x=200, y=120)

    # --------------------------------------------------------------------------------------------------------------------

    label3 = tk.Label(wind, text="Next Checkup", font=("times new roman", 13, "bold"))
    label3.pack()
    label3.place(x=20, y=170)

    entry3 = tk.Entry(wind, width=30, fg="black", bg="white", textvariable=next)
    entry3.pack()
    entry3.place(x=200, y=170)

    # --------------------------------------------------------------------------------------------------------------------

    label4 = tk.Label(wind, text="CNIC", font=("times new roman", 13, "bold"))
    label4.pack()
    label4.place(x=20, y=220)

    entry4 = tk.Entry(wind, width=30, fg="black", bg="white", textvariable=cnic)
    entry4.pack()
    entry4.place(x=200, y=220)

    # --------------------------------------------------------------------------------------------------------------------

    label5 = tk.Label(wind, text="Doctor", font=("times new roman", 13, "bold"))
    label5.pack()
    label5.place(x=20, y=270)

    entry5 = tk.Entry(wind, width=30, fg="black", bg="white", textvariable=Doctor)
    entry5.pack()
    entry5.place(x=200, y=270)

    # For the button Schedule Appointment

    plus_image = Image.open('plus.png')
    size_img = plus_image.resize((10, 10))
    plus_img = ImageTk.PhotoImage(size_img)

    schedule = tk.Button(wind, text=" Schedule Appointment", fg="black", font=("Calibri", 12), width=180, height=20,
                         image=plus_img, compound="left",
                         command=lambda: addAppointment(conn, appoin_date.get(), eme_appoin.get(), next.get(),
                                                        cnic.get(), Doctor.get()))

    schedule.pack()
    schedule.place(x=200, y=320)

    wind.mainloop()


def delete_appointmentsGUI():
    wind = tk.Toplevel(window)
    wind.title("Schedule An Appointment")

    wind.geometry("500x300")
    label1 = Label(wind, image=image)

    label1.pack()
    heading = Label(wind, text="Delete An Appointment", font=("Calibri", 20, "bold"), fg="red")
    heading.pack()

    heading.place(x=100, y=10)
    label1 = tk.Label(wind, text="SERIAL #", font=("times new roman", 13, "bold"))
    label1.pack()

    label1.place(x=20, y=70)
    entry1 = tk.Entry(wind, width=30, fg="black", bg="white", textvariable=ser_no)
    entry1.pack()

    entry1.place(x=200, y=70)

    delete = tk.Button(wind, text=" Delete Appointments", fg="black", font=("Calibri", 12), width=220, height=30,
                       image=plus_img, compound="left",
                       command=lambda: deleteAppointment(conn, cnic.get(), ser_no.get()))
    delete.pack()

    delete.place(x=90, y=150)

    wind.mainloop()


def View_appointments(conn, cnic):
    print("Read")
    temp = False

    cursor = conn.cursor()
    cursor.execute("select * from Norm_Appointments where CNIC=?", (cnic))
    i = 0
    my_w = tk.Tk()
    my_w.geometry("1000x200")
    for row in cursor:
        for j in range(len(row)):
            e = Entry(my_w, width=30, fg='blue')
            e.grid(row=i, column=j)
            e.insert(END, row[j])
        i = i + 1
    my_w.mainloop()


def deleteAppointment(conn, cnic, ser):
    # id = int(input("Enter the serial number: "))

    c = conn.cursor()
    c.execute("delete from Norm_Appointments where serial_number = ? AND CNIC = ?", (ser, cnic))
    c.commit()


def addAppointment(conn, apoint, eme, nc, cnic, doc):
    c = conn.cursor()

    c.execute("insert into Norm_Appointments values (?, ?, ?, ?, ?)", (apoint, eme, nc, cnic, doc))

    c.execute("insert into N2_Appointments_Doctors values (?, ?)", (cnic, doc))

    c.execute("insert into N2_Appointments_Schedule values (?, ?, ?, ?)", (apoint, eme, nc, cnic))

    c.commit()


def update_patient_record(conn, val, update, cnic):
    if val == "First_Name":
        cursor = conn.cursor()
        cursor.execute("Update Clients set First_Name = ? where CNIC = ?", (update, cnic))
    elif val == "last_Name":
        cursor = conn.cursor()
        cursor.execute("Update Clients set Last_Name = ? where CNIC = ?", (update, cnic))
    elif val == "Primary_Contact_Number":
        cursor = conn.cursor()
        cursor.execute("Update Clients set Primary_Contact_Number = ? where CNIC = ?", (update, cnic))
    elif val == "Emergency_Contact_Number":
        cursor = conn.cursor()
        cursor.execute("Update Clients set Emergency_Contact_Number = ? where CNIC = ?", (update, cnic))
    elif val == "Email_Address":
        cursor = conn.cursor()
        cursor.execute("Update Clients set Email_Address = ? where CNIC = ?", (update, cnic))

    conn.commit()


def PrescriptionsGUI(cnic):
    wind = tk.Toplevel(window)
    wind.title("View Prescriptions")
    wind.geometry("500x250")

    image = ImageTk.PhotoImage(file="hcs1.png")

    label1 = Label(wind, image=image)
    label1.pack()

    c = conn.cursor()
    c.execute("Select Prescriptions from MedicalRecord where CNIC = ?", (cnic))
    i = 0
    for temp in c:
        for j in range(len(temp)):
            e = Entry(label1, width=100, fg='blue')
            e.grid(row=i, column=j)
            e.insert(END, temp[j])
        i = i + 1

    wind.mainloop()


# ---------------------------------------------------------------------------------------------------------------------

def ClientPortal(windo):
    wind = tk.Toplevel(window)
    wind.title("Client Dashboard")

    wind.geometry("1015x428")
    windo.withdraw()

    image = ImageTk.PhotoImage(file="hcs1.png")

    date = datetime.now()
    label01 = Label(wind, image=image)

    label01.pack()
    heading01 = Label(wind, text="CLIENT'S DASHBOARD", font=("Calibri", 20, "bold"), fg="green")
    heading01.pack()

    heading01.place(x=380, y=10)
    date_button = tk.Button(wind, text=f"{date:%A, %B %d, %Y}", fg="black", font=("Calibri", 10), width=20, height=1)
    date_button.pack()

    date_button.place(x=5, y=10)
    button01 = tk.Button(wind, text="SIGN OUT", fg="black", bg='#B5D5C5', font=("Calibri", 10), width=10, height=1, command= lambda : SignOut(wind))
    button01.pack()

    button01.place(x=932, y=10)
    edit = tk.Button(wind, text="EDIT PROFILE", fg="black", bg='#B5D5C5', font=("Calibri", 10), width=10, height=1,
                     command=UpdatePatientGUI)
    edit.pack()

    edit.place(x=932, y=40)
    welcome_text = Label(wind, text="Welcome, Have a good day :)", font=("Calibri", 20, "italic"),
                         fg="blue")
    welcome_text.pack()

    # For My Dashboard Button

    welcome_text.place(x=100, y=175)
    home = Image.open("home.png")
    size_home = home.resize((20, 20))

    new_home = ImageTk.PhotoImage(size_home)

    dashboard = tk.Button(wind, text=" My Dashboard", fg="black", font=("Calibri", 12), width=180, height=20, image=new_home,
                          compound="left")
    dashboard.pack()

    # For Scheduling an Appointment Button

    dashboard.place(x=40, y=100)
    plus_image = Image.open('plus.png')
    size_img = plus_image.resize((10, 10))

    plus_img = ImageTk.PhotoImage(size_img)

    view_report = tk.Button(wind, text=" Schedule an Appointment", fg="black", font=("Calibri", 12), width=180, height=20,
                            image=plus_img, compound="left", command=lambda: ScheduleAnAppointmentGUI())
    view_report.pack()

    # For Manage Appointments Button

    view_report.place(x=227, y=100)
    manage = Image.open("manage.png")
    size_manage = manage.resize((20, 20))

    new_manage = ImageTk.PhotoImage(size_manage)

    manage_appointments = tk.Button(wind, text=" Manage Appointments", fg="black", font=("Calibri", 12), width=180, height=20,
                                    image=new_manage, compound="left", command=lambda: ManageAppointmentsGUI())
    manage_appointments.pack()

    # For Blood Bank Button

    manage_appointments.place(x=414, y=100)
    blood = Image.open("blood.png")
    size_blood = blood.resize((20, 20))

    new_blood = ImageTk.PhotoImage(size_blood)

    blood_bt = tk.Button(wind, text=" Blood Bank", fg="black", font=("Calibri", 12), width=180, height=20, image=new_blood,
                         compound="left", command=BloodBankGUI)
    blood_bt.pack()

    # For Prescriptions

    blood_bt.place(x=601, y=100)
    report = Image.open("report.png")
    size_report = report.resize((20, 20))

    new_report = ImageTk.PhotoImage(size_report)

    view_report = tk.Button(wind, text=" View Prescriptions", fg="black", font=("Calibri", 12), width=180, height=20,
                            image=new_report, compound="left", command=lambda: PrescriptionsGUI(cnic.get()))
    view_report.pack()

    view_report.place(x=788, y=100)

    wind.mainloop()


# ---------------------------------------------------------------------------------------------------------------------


window = tk.Tk()
window.title("ONLINE HEALTHCARE MANAGEMENT SYSTEM")
window.geometry("1500x2000")
window.configure(bg="#D6E4E5", borderwidth='20', relief="ridge")
window_label = tk.Label(window, text="ONLINE HEALTH-CARE MANAGEMENT SYSTEM", relief="ridge", bg="#E0ECE4", fg="#234C63",
                        font=("times new roman", 30, "bold"))
window_label.pack()
window_label.place(x=200, y=10)

"PATIENT VARIABLES"

user_name = tk.StringVar()
user_pass = tk.StringVar()
f_name = tk.StringVar()
l_name = tk.StringVar()
cnic = tk.StringVar()
mob = tk.StringVar()
em_mob = tk.StringVar()
email = tk.StringVar()
value = tk.StringVar()

"APPOIN VARIABLES"

appoin = tk.StringVar()
eme = tk.StringVar()
next = tk.StringVar()
doc_id = tk.StringVar()
updatevalue = tk.StringVar()
serial = tk.IntVar()


appoin_date = tk.StringVar()
eme_appoin = tk.StringVar()
# next = tk.StringVar()
Doctor = tk.IntVar()
# cnic = tk.StringVar()
# updatevalue = tk.StringVar()
ser_no = tk.IntVar()


image = ImageTk.PhotoImage(file="hcs1.png")

plus_image = Image.open('plus.png')
size_img = plus_image.resize((10, 10))

plus_img = ImageTk.PhotoImage(size_img)


image1 = Image.open("medical-health-hospital-logo-icon-vector-27693606.jpg")
test = ImageTk.PhotoImage(image1)

label1 = tk.Label(image=test)
label1.image = test

# Position image
label1.place(x=350, y=90)

label2 = tk.Label(window, text="WE ARE HERE TO CARE FOR YOUR HEALTH", font=("calibri", 29, "bold"), bg="#D6E4E5")
label2.pack()
label2.place(x=330, y=450)
label2 = tk.Label(window, text="The online healthcare management system (OHMS) will provide ease of access to both "
                               "doctors and users.\nThe patients, users, medical practitioner,or doctors will be able "
                               "to view, update,\n and see the history of the patient’s medical record anywhere "
                               "in the world.", font=("calibri", 13, "bold"), bg="#D6E4E5")
label2.pack()
label2.place(x=300, y=500)

button1 = tk.Button(window, text="SIGN IN DOCTOR", fg="#181D31", relief="ridge", bg="#BAD1C2",
                    font=("times new roman", 16, "bold"), width=20, height=1, command=lambda: signing_in_Doctor())
button1.pack()
button1.place(x=400, y=585)


button2 = tk.Button(window, text="SIGN IN CLIENT", fg="#181D31", relief="ridge", bg="#BAD1C2",
                    font=("times new roman", 16, "bold"), width=20, height=1, command=lambda: signing_in_Client())
button2.pack()
button2.place(x=650, y=585)

window.mainloop()
